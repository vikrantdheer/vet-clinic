package net.serenitybdd.dojo.supermarket.model;

public class DummyCatalog implements SupermarketCatalog {
    @Override
    public Receipt checkOut(ShoppingCart theCart) {
        return Receipt.calculateBillFor(theCart);
    }
}
