package net.serenitybdd.dojo.supermarket.model;

public class Teller {

    private final SupermarketCatalog catalog;

    public Teller(SupermarketCatalog catalog) {
        this.catalog = catalog;
    }

    public Receipt checksOutArticlesFrom(ShoppingCart theCart) {
        return this.catalog.checkOut(theCart);
    }

//    public Receipt checksOutArticlesFrom(ShoppingCart cart) {
//        Receipt receipt = new Receipt();
////        theCart.getCartMap().forEach(
////                (products, integer) -> receipt.addProduct(products,
////                integer));
//        return receipt;
}