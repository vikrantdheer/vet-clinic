package net.serenitybdd.dojo.supermarket.model;

import net.serenitybdd.dojo.supermarket.Products;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {

    private Products products;
    private int quantity;

    private final List<Products> items = new ArrayList<>();

    public List<Products> getItems() {
        return new ArrayList<>(items);
    }

    public void addItem(Products product) {
        items.add(product);
    }

    public ShoppingCartBuilder add(Products product) {
        return new ShoppingCartBuilder(this, product);
    }

    public int getQuantityOf(Products product) {
        items.contains(product);
        return 0;
    }

    public class ShoppingCartBuilder {
        private final ShoppingCart shoppingCart;
        private final Products product;

        public ShoppingCartBuilder(ShoppingCart shoppingCart, Products product) {
            this.shoppingCart = shoppingCart;
            this.product = product;
        }

        public void withQuantity(int quantity) {
            for (int count = 0; count < quantity; count++) {
                shoppingCart.addItem(product);
            }
        }
    }
}
