package net.serenitybdd.dojo.supermarket.model;

public interface SupermarketCatalog {
    public Receipt checkOut(ShoppingCart theCart);
}
