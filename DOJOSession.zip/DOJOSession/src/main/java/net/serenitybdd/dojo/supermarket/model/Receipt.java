package net.serenitybdd.dojo.supermarket.model;

import net.serenitybdd.dojo.supermarket.Products;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

public class Receipt {

    private double totalBillAmount = 0.00;

    private static final AtomicInteger number = new AtomicInteger();

    public int receiptNumber;
    private List<Products> productsPurchased;

    public Receipt(int receiptNumber, double totalBillAmount, List<Products> productsPurchased) {
        this.receiptNumber = receiptNumber;
        this.totalBillAmount = totalBillAmount;
        this.productsPurchased = productsPurchased;
    }

    public Receipt() {

    }

    public double getTotalBillAmount() {
        return totalBillAmount;
    }

    public static Receipt calculateBillFor(ShoppingCart cart) {
        double calculatedAmount = 0.00;
        if (cart.getItems() != null) {
            List<Products> productsInCart = cart.getItems();

            for (Products product : productsInCart) {
                calculatedAmount += product.getPrice();
            }

//            Map<Integer, Long> map2 =
//                    productsInCart.stream()
//                            .collect(Collectors.groupingBy(Products::getPrice, Collectors.counting()));
//            System.out.println(map2);

            return new Receipt(number.incrementAndGet(), calculatedAmount, productsInCart);  //To change body of created methods use File | Settings | File Templates.
        } else
            return new Receipt();
    }

    public List<Products> getProductsPurchased() {
        return productsPurchased;
    }
}
