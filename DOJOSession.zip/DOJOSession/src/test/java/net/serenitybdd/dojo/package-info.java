/**
 * Tests go here.
 */
package net.serenitybdd.dojo;