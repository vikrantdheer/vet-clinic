package net.serenitybdd.dojo.supermarket;

import net.serenitybdd.dojo.supermarket.model.*;
import org.junit.Before;
import org.junit.Test;

import static net.serenitybdd.dojo.supermarket.Products.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.notNullValue;

public class WhenCheckingOutArticlesAtTheSupermarket {

    SupermarketCatalog catalog;
    Teller teller;
    ShoppingCart cart;

    @Before
    public void initializeCart() {
        catalog = new DummyCatalog();
        teller = new Teller(catalog);
        cart = new ShoppingCart();
    }

    @Test
    public void initial_cart_should_be_empty() {
        //THEN
        assertThat(cart.getItems(), empty());
    }

    @Test
    public void should_be_able_to_add_single_item() {
        //WHEN
        cart.addItem(TOOTHPASTE);

        //THEN
        assertThat(cart.getItems().size(), equalTo(1));
    }

    @Test
    public void should_be_able_to_add_multiple_items() {
        //WHEN
        cart.add(TOOTHPASTE).withQuantity(2);
        cart.add(APPLES).withQuantity(4);

        //THEN
        assertThat(cart.getItems().size(), equalTo(6));
    }

    @Test
    public void teller_should_be_able_to_checkout_a_toothpaste() {

        cart.add(TOOTHPASTE).withQuantity(2);

        Receipt receipt = teller.checksOutArticlesFrom(cart);

        // THEN
        assertThat(receipt.getTotalBillAmount(), equalTo(20.00));
    }

    @Test
    public void teller_should_be_able_to_checkout_multiple_products() {

        //WHEN
        cart.add(TOOTHPASTE).withQuantity(2);
        cart.add(APPLES).withQuantity(4);

        Receipt receipt = teller.checksOutArticlesFrom(cart);

        // THEN
        assertThat(receipt.getTotalBillAmount(), equalTo(140.00));
    }

    @Test
    public void teller_should_be_able_to_handle_duplicate_products() {

        //WHEN
//        cart.addProductsToCart(TOOTHBRUSH, 1);
//        cart.addProductsToCart(TOOTHBRUSH, 1);

        //THEN
//        assertThat(theCart.getProductList()), equalTo(1));
//        assertThat(theCart.getQuantityFor(Products.TOOTHBRUSH), equalTo(2));
    }

    // The client should get a receipt with the list of purchases and the total price.

    @Test
    public void client_should_get_a_receipt_with_products_and_price() throws Exception {

        //GIVEN
        cart.add(TOOTHPASTE).withQuantity(2);
        cart.add(APPLES).withQuantity(2);

        //WHEN
        Receipt receipt = teller.checksOutArticlesFrom(cart);

        //THEN
        assertThat(receipt.receiptNumber, is(notNullValue()));
        assertThat(receipt.getTotalBillAmount(), equalTo(80.00));
        assertThat(receipt.getProductsPurchased(), equalTo(cart.getItems()));
    }

}
